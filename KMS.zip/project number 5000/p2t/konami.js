let LEFT_ARROW = 'left'
let DOWN_ARROW = 'down'
let RIGHT_ARROW = 'right'
let UP_ARROW = 'up'

let sequence = ''


document.addEventListener('keydown', function(e) {
    switch (e.keyCode) {
        case 37:
            sequence = sequence + LEFT_ARROW
            console.log(LEFT_ARROW);
            break;
        case 38:
            sequence = sequence + UP_ARROW   
            console.log(UP_ARROW);
            break;
        case 39:
            sequence = sequence + RIGHT_ARROW
            console.log(RIGHT_ARROW);
            break;
        case 40:
            sequence = sequence + DOWN_ARROW        
            console.log(DOWN_ARROW);
            break;
        default:
            sequence = ''
        }
console.log(sequence);

if (sequence==='upupdowndownleftrightleftright'){
    window.location.href='14s5asfvc.html';
};
    }
);


